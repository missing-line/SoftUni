﻿namespace AnimalCentre.Models.Contracts
{
    public interface IEngine
    {
        void Run();
    }
}
