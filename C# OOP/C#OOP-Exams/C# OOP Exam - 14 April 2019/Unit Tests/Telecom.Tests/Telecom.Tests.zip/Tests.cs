namespace Telecom.Tests
{
    using NUnit.Framework;
    using System;
    public class Tests
    {

        [Test]
        public void Initi()
        {
            Phone phone = new Phone("name", "ip");

            Assert.That(phone.Make, Is.EqualTo("name"));
            Assert.That(phone.Model, Is.EqualTo("ip"));
            Assert.That(phone.Count, Is.EqualTo(0));
        }

        [Test]
        public void AddContact()
        {
            Phone phone = new Phone("name", "ip");
            phone.AddContact("opa", "032");

            Assert.That(phone.Count, Is.EqualTo(1));
        }

        [Test]
        public void Throw()
        {
            Phone phone = new Phone("name", "ip");
            phone.AddContact("opa", "032");
            Assert.Throws<InvalidOperationException>(()
                => phone.AddContact("opa", "032"));
        }

        [Test]
        public void Calling()
        {
            //$"Calling {name} - {number}...";
            Phone phone = new Phone("name", "ip");
            phone.AddContact("opa", "032");

            string actual = phone.Call("opa");
            Assert.That(actual, Is.EqualTo("Calling opa - 032..."));
        }

        [Test]
        public void ThrowWith_Call()
        {
            Phone phone = new Phone("name", "ip");

            Assert.Throws<InvalidOperationException>(()
                => phone.Call("opa"));
        }

        [Test]
        public void InitiThrwo()
        {
            Assert.Throws<ArgumentException>(()
               => new Phone("", "opaaa"));

            Assert.Throws<ArgumentException>(()
               => new Phone("opaaaa", ""));
        }
    }
}