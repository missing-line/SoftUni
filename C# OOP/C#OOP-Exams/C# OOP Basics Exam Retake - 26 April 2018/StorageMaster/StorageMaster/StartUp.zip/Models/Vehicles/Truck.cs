﻿namespace StorageMaster.Models.Vehicles
{
    public class Truck : Vehicle
    {
        public Truck() 
            : base(5)
        {
        }
    }
}
