﻿namespace StorageMaster.Models.Intefaces
{
    public interface IEngine
    {
        void Run();
    }
}
