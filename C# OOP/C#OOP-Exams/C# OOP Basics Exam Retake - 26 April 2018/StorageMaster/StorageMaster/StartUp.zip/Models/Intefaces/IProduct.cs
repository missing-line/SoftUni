﻿namespace StorageMaster.Models.Intefaces
{
    public interface IProduct
    {
        double Price { get; }
        double Weight { get; }
    }
}
