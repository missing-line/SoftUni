﻿namespace Ado.Net_Demo
{
    public static class Configuretion
    {
        public const string connection = "Server=.\\SQLEXPRESS;Integrated Security=True";

        public const string connectionString = "Server=.\\SQLEXPRESS;DataBase=MinionsDB;Integrated Security=True";

    }
}
