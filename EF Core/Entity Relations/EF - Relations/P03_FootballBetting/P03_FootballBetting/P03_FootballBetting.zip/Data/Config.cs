﻿namespace P03_FootballBetting.Data
{
    public class Config
    {
        public const string Connection = "Server=.\\SQLEXPRESS;Database=FootballBetting;Integrated Security=True;";
    }
}
