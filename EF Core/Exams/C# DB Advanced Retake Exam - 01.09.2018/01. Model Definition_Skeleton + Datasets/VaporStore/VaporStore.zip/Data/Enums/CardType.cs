﻿namespace VaporStore.Data.Enums
{
    public enum CardType
    {
        Debit = 0,
        Credit = 1
    }
}
